console.log("hello world");
const name = prompt("Your name");
document.write(name);
//document.getElementById("run").innerHTML=joke;